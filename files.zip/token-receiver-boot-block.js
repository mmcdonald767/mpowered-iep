/* ═══════════════════════════════════════════════════════════════════
   TOKEN RECEIVER BOOT BLOCK
   mpowered-iep / index.html  —  top of the <script> block
   ─────────────────────────────────────────────────────────────────
   PLACEMENT: This IIFE must be the FIRST thing inside the <script>
   tag at the bottom of <body> (or in a separate <script> tag placed
   immediately before any other <script> tags). It must execute
   before initGoalBank(), before any DOMContentLoaded listeners,
   and before any session guard that would redirect the user.

   INSERTION POINT IN index.html:
     Line ~721  →  <script>
     Line ~722  →  'use strict';
                    ↑ Insert this entire block IMMEDIATELY after
                      'use strict'; and before the GOAL_BANK_MATRIX
                      declaration. The guard at the bottom of this
                      block must run before any code that reads
                      sessionStorage for auth state.

   WHY IT RUNS FIRST:
   The dashboard (mpowerededucation.com/dashboard.html) calls
   navigateWithToken(), which appends the OAuth access token as a
   URL hash fragment:
     https://iep.mpowerededucation.com/#access_token=<token>
   This page must harvest that fragment, persist it to local
   sessionStorage, and strip it from the address bar before the
   main application session guard checks for a valid token.
   If this block does not run first, the guard will see an empty
   sessionStorage, treat the session as unauthenticated, and
   redirect the user back to the login page — even though a valid
   token arrived in the URL.

   AUTH ARCHITECTURE CONTEXT:
   - The wildcard cookie (Domain=.mpowerededucation.com, set by
     the OAuth provider on the root domain) is automatically sent
     by the browser on requests to this subdomain, but is only
     readable by the server. Client-side JS cannot read HttpOnly
     cookies. SessionStorage is the client-side auth signal.
   - SessionStorage does NOT cross origins. The token stored in
     sessionStorage on mpowerededucation.com is NOT available
     here on iep.mpowerededucation.com. The hash fragment
     handshake is therefore the required bootstrap mechanism for
     first load on each subdomain.
   - Once stored, the token persists in this subdomain's
     sessionStorage for the lifetime of the browser tab. The
     wildcard cookie handles re-authentication across tabs.
═══════════════════════════════════════════════════════════════════ */
(function mpBootReceiver() {
  'use strict';

  /* ── Step 1: Bail early if we already have a token ────────────
     If sessionStorage already holds a valid token (e.g. the user
     is navigating back within the same tab), skip the hash parse.
     This prevents a stale hash from a cached URL from overwriting
     a fresher token that was established later in the session.   */
  var existingToken = null;
  try {
    existingToken = sessionStorage.getItem('oauth_token');
  } catch (storageErr) {
    // sessionStorage blocked (private browsing restrictions, etc.)
    // Fall through — we'll still attempt to read the hash.
  }

  if (existingToken) {
    // Token already present — strip any hash fragment defensively
    // to prevent the raw token from sitting in the address bar.
    if (window.location.hash) {
      history.replaceState(null, '', window.location.pathname + window.location.search);
    }
    return; // Exit — session is already bootstrapped.
  }

  /* ── Step 2: Read and parse the URL hash fragment ─────────────
     Expected format (set by dashboard.html navigateWithToken()):
       #access_token=<url-encoded-token>
     We parse only this key. Any other fragment values (e.g. from
     a direct link with an anchor) are left untouched in the
     address bar — we only act on a recognized auth payload.       */
  var rawHash = window.location.hash; // e.g. "#access_token=eyJ..."

  if (!rawHash || rawHash.length <= 1) {
    // No hash at all — check if we have a valid session another way.
    // If not, the session guard below will handle the redirect.
    return;
  }

  // Strip the leading '#' and split into key=value pairs.
  // This handles compound hashes like #access_token=x&state=y
  var hashParams = {};
  rawHash.slice(1).split('&').forEach(function (pair) {
    var parts = pair.split('=');
    if (parts.length >= 2) {
      var key = decodeURIComponent(parts[0]);
      // Rejoin on '=' to handle base64-encoded tokens that contain '='
      var val = decodeURIComponent(parts.slice(1).join('='));
      hashParams[key] = val;
    }
  });

  var inboundToken = hashParams['access_token'] || null;

  /* ── Step 3: Validate the inbound token (basic sanity check) ──
     We don't verify the JWT signature here (that's the server's
     job). We do reject obviously malformed values: empty strings,
     values shorter than 20 chars (no valid JWT or OAuth token is
     that short), or values containing characters outside the
     expected token alphabet.
     Extend this regex if your OAuth provider uses non-standard
     characters in its tokens.                                     */
  var TOKEN_PATTERN = /^[A-Za-z0-9\-_\.\/+]+$/;
  var TOKEN_MIN_LEN = 20;

  if (
    !inboundToken ||
    inboundToken.length < TOKEN_MIN_LEN ||
    !TOKEN_PATTERN.test(inboundToken)
  ) {
    // Token is absent or malformed — clean the URL and let the
    // session guard below decide what to do.
    if (rawHash) {
      history.replaceState(null, '', window.location.pathname + window.location.search);
    }
    return;
  }

  /* ── Step 4: Persist to sessionStorage ────────────────────────
     Write the token and a timestamp so other parts of the app
     (and any future session renewal logic) can reference them.
     These keys must match exactly what dashboard.html writes via
     grantAccess() and what the session guard below reads.         */
  try {
    sessionStorage.setItem('oauth_token',    inboundToken);
    sessionStorage.setItem('mp_beta_auth_time', Date.now().toString());
    // mp_beta_email is not available in the hash fragment — it was
    // stored in sessionStorage on the root domain by grantAccess()
    // and cannot cross the subdomain boundary. The header email
    // display on this subdomain will simply render empty on first
    // load if no email is present. Subsequent loads (same tab)
    // will have it if the user navigated here from the dashboard
    // in the same session.
  } catch (writeErr) {
    // If sessionStorage write fails (quota, privacy mode), the
    // session guard below will redirect. Nothing more we can do
    // client-side without a valid storage mechanism.
    console.warn('[mpBootReceiver] sessionStorage write failed:', writeErr);
  }

  /* ── Step 5: Strip the hash from the address bar ──────────────
     SECURITY: Leaving #access_token= in the URL is dangerous:
       • It appears in browser history entries.
       • It appears in Referer headers on outbound links.
       • It's visible to any JS loaded on this page (analytics,
         error reporters, browser extensions).
     history.replaceState() rewrites the address bar entry without
     triggering a page reload or creating a new history entry.
     We preserve the pathname and query string so any legitimate
     query params survive.                                         */
  history.replaceState(
    null,
    '',
    window.location.pathname + window.location.search
    // Intentionally omit window.location.hash — this strips it.
  );

  // Boot complete. sessionStorage now contains the token.
  // The application's session guard will find it and proceed.
  console.log('[mpBootReceiver] Token received and stored. Hash cleared from URL.');

}()); // End IIFE — executes immediately, leaves no global scope pollution.


/* ═══════════════════════════════════════════════════════════════════
   SESSION GUARD
   ─────────────────────────────────────────────────────────────────
   PLACEMENT: Immediately after the boot block above.
   Runs after the boot block has had a chance to write the token
   to sessionStorage from the inbound hash fragment.

   If no token is present after the boot block runs, this guard
   redirects the user to the root login page with a `next` param
   so they land back here after authenticating.
═══════════════════════════════════════════════════════════════════ */
(function mpSessionGuard() {
  'use strict';

  var token = null;
  try {
    token = sessionStorage.getItem('oauth_token');
  } catch (e) {}

  if (!token) {
    // No token found after boot block ran — user is not authenticated.
    // Redirect to root login. The `next` param enables the login page
    // to redirect back here after a successful OAuth callback.
    var returnPath = encodeURIComponent(
      window.location.pathname + window.location.search
    );
    window.location.replace(
      'https://mpowerededucation.com/index.html?next=' + returnPath
    );
  }
}());
